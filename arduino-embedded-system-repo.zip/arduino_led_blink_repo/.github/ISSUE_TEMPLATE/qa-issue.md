---
name: QA Issue
about: Record a software, hardware, or documentation problem
title: "[QA] "
labels: ""
assignees: ""
---

## Problem description
Describe the observed problem and how to reproduce it.

## Severity
Low / Medium / High

## Root-cause analysis (5 Whys)
1. Why?
2. Why?
3. Why?
4. Why?
5. Why?

## Proposed solution
Describe the intended fix and files affected.

## Acceptance criteria
- [ ] The fix addresses the root cause.
- [ ] Relevant test/documentation is updated.
